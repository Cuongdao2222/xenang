<?php
	echo phpinfo();

?>