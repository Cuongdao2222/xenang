<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class products1 extends Model
{
    public $table = 'product1';
}
