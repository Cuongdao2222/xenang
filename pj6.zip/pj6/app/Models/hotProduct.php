<?php

namespace  App\Models;

use Illuminate\Database\Eloquent\Model;

class hotProduct extends Model
{
    public $table = 'hot';
}
