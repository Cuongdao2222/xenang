<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class deal extends Model
{
     public $table = 'deal';
}
