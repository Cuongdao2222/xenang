<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class landing extends Model
{
    public $table = 'landing_product';
}
