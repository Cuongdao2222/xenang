# firstChild

```php
firstChild ( ) : mixed
```

This function is a wrapper for [`first_child`](../first_child/)