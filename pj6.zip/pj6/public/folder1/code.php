<?php 


	echo"code.php"
?>